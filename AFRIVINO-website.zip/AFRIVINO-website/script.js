document.addEventListener("DOMContentLoaded", () => {
  const ageScreen = document.getElementById("ageScreen");
  const ageYes = document.getElementById("ageYes");
  const ageNo = document.getElementById("ageNo");
  const accepted = sessionStorage.getItem("afrivino-age-confirmed") === "yes";
  if (accepted) ageScreen.classList.add("hidden");
  document.body.classList.toggle("locked", !accepted);
  ageYes.addEventListener("click", () => {
    sessionStorage.setItem("afrivino-age-confirmed", "yes");
    ageScreen.classList.add("hidden");
    document.body.classList.remove("locked");
  });
  ageNo.addEventListener("click", () => {
    ageScreen.innerHTML = '<div class="age-card"><h1>Thank you for visiting.</h1><p class="muted">This website is intended only for people of legal drinking age.</p></div>';
  });
  const menuToggle = document.getElementById("menuToggle");
  const navLinks = document.getElementById("navLinks");
  menuToggle.addEventListener("click", () => {
    const open = navLinks.classList.toggle("open");
    menuToggle.setAttribute("aria-expanded", String(open));
    menuToggle.setAttribute("aria-label", open ? "Close navigation" : "Open navigation");
  });
  navLinks.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
    navLinks.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }));
  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });
  document.querySelectorAll(".reveal").forEach(el => revealObserver.observe(el));
  document.getElementById("year").textContent = new Date().getFullYear();
  document.getElementById("contactForm").addEventListener("submit", event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const subject = encodeURIComponent("AFRIVINO website enquiry");
    const body = encodeURIComponent("Name: " + data.get("name") + "\nEmail: " + data.get("email") + "\n\nMessage:\n" + data.get("message"));
    document.getElementById("formStatus").textContent = "Opening your email app with your message…";
    window.location.href = "mailto:hello@afrivino.com?subject=" + subject + "&body=" + body;
  });
});